merged.data=list()
merged.data$MLY2=MLY2
merged.data$MLY3=MLY3
merged.data$MLY4=MLY4
merged.data$MLY5=MLY5

merged.data=merge(MLY2,y=c(MLY3,MLY4,MLY5))

#Remove mitochondrial genes
Mt_genes=grep("^MT-",rownames(merged.data@assays$RNA),value=TRUE)
counts=GetAssayData(merged.data,assay="RNA")
counts=counts[-(which(rownames(counts) %in% Mt_genes)),]
merged.data=subset(merged.data,features=rownames(counts))




#Standardization, identification of high-variation genes, data scaling, and dimensionality reduction
merged.data=SCTransform(merged.data,verbose=T,vars.to.regress=c('percent.mt'),method="glmGamPoi",
                        vst.flavor="v2")

DefaultAssay(merged.data)="SCT" 

merged.data=RunPCA(merged.data,npcs=50,features=merged.data@assays[["SCT"]]@var.features,assay="SCT")

#Remove batch effects
merged.data=RunHarmony(merged.data,group.by.vars="group",plot_convergence=T,lambda=1,assay="SCT")

merged.data=merged.data %>% 
  FindNeighbors(reduction="harmony",dims=1:30,assay="SCT") %>% 
  FindClusters(resolution=0.2,assay="SCT") %>% 
  #RunUMAP(reduction="css",dims=1:ncol(Embeddings(merged.data,"css")))
  RunUMAP(reduction="harmony",dims=1:30,min.dist=0.01,assay="SCT") %>%
  identity()

DotPlot(merged.data,features=c("NEGR1","DCN","PDGFRA",
                               "VWF","PECAM1","CDH13",
                               "SMOC1","NPR3",
                               "KCNJ8","ABCC9","EGFLAM",
                               "NRXN1","NRXN3",
                               "MYH11",
                               "TNNT2","RYR2","MYBPC3",
                               "MMRN1",
                               "PTPRC","LYVE1","SKAP1",
                               "MSLN","WT1","BNC1","SLC39A8",
                               "GPAM","FASN","ADIPOQ"),
        group.by="seurat_clusters")+coord_flip()

#Cell annotation
new.cluster.ids=c("0"="vessel_endothelial","1"="Pericytes",
                  "2"="Fibroblasts","3"="vessel_endothelial",
                  "4"="Cardiomyocytes",
                  "5"="SMC",
                  "6"="Macrophages","7"="Neuronal",
                  "8"="vessel_endothelial","9"="T",
                  "10"="Mesothelial","11"="Lym_endothelial",
                  "12"="Atrial_endothelial","13"="Adipocytes")

merged.data[['cell_type']]=unname(new.cluster.ids[merged.data@meta.data$seurat_clusters])











