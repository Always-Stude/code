library(Seurat)
library(SeuratObject)
library(dplyr)
library(patchwork)
library(sctransform)
library(progress)
library(DoubletFinder)
library(patchwork)

MLY3.data=Read10X("C:\\代码\\数据分析\\MLY3")
MLY3=CreateSeuratObject(counts=MLY3.data,project="MLY3",min.cells=3,min.features=200)
MLY3[["percent.mt"]]=PercentageFeatureSet(MLY3,pattern="^MT-")
#Calculate ribosome genes
rb.genes=rownames(MLY3)[grep("^RP[SL]",rownames(MLY3))]
percent.ribo=Matrix::colSums(MLY3[rb.genes,])/Matrix::colSums(MLY3)*100
MLY3=AddMetaData(MLY3, percent.ribo, col.name="percent.ribo")


MLY3=NormalizeData(MLY3, normalization.method="LogNormalize")
MLY3=FindVariableFeatures(MLY3, selection.method="vst",nfeatures=2000)
all.genes=rownames(MLY3)
MLY3=ScaleData(MLY3, features=all.genes)
MLY3=RunPCA(MLY3)
#Check the elbow shape diagram and heat map
ElbowPlot(MLY3,ndims = 40)
DimHeatmap(MLY3,dims=1:30,cells=500,balanced=TRUE)

MLY3=RunUMAP(MLY3,dims=1:30,verbose=FALSE) 
MLY3=FindNeighbors(MLY3,dims=1:30,verbose=FALSE)
MLY3=FindClusters(MLY3,verbose=FALSE,resolution=0.5)

DimPlot(MLY3,reduction="umap",label=TRUE,repel=TRUE)

#Quality control: First, filter out the double cells
sweep.res.list_keloid=paramSweep(MLY3,PCs=1:30,sct=F)
head(sweep.res.list_keloid)

sweep.stats_keloid=summarizeSweep(sweep.res.list_keloid, GT=FALSE)
bcmvn_keloid=find.pK(sweep.stats_keloid) #可以看到最佳参数的点
#The optimal parameter is: 0.005
mpK=0.005
mpK=as.numeric(as.vector(bcmvn_keloid$pK[which.max(bcmvn_keloid$BCmetric)]))

#Calculate the proportion of two cells
annotations=MLY3@meta.data$seurat_clusters
homotypic.prop=modelHomotypic(annotations)  

#Calculate the proportion of double cells and artificially mix the double cells based on the parameters in modelHomotypic
DoubletRate=0.076
nExp_poi=round(DoubletRate*nrow(MLY3@meta.data))  
nExp_poi.adj=round(nExp_poi*(1-homotypic.prop))

#There are two methods for identifying double cells
MLY3=doubletFinder(MLY3, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi, reuse.pANN=FALSE,sct=F)
MLY3=doubletFinder(MLY3, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi, reuse.pANN="pANN_0.25_0.005_959",sct=F)

MLY3=doubletFinder(MLY3, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi.adj,reuse.pANN=FALSE,sct=F)
MLY3=doubletFinder(MLY3, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi.adj,reuse.pANN="pANN_0.25_0.005_819",sct=F)

#visualization
DimPlot(MLY3,reduction="umap",group.by ="RNA_snn_res.0.5")+DimPlot(MLY3,reduction="umap",group.by ="DF.classifications_0.25_0.005_959",cols=c("black","grey","gold"))
table(MLY3@meta.data$DF.classifications_0.25_0.005_959)#959+11657

DimPlot(MLY3,reduction="umap",group.by ="RNA_snn_res.0.5")+DimPlot(MLY3,reduction="umap",group.by ="DF.classifications_0.25_0.005_819",cols=c("black","grey","gold"))
table(MLY3@meta.data$DF.classifications_0.25_0.005_819)#819+11797

#filtration
MLY3=subset(MLY3,subset=DF.classifications_0.25_0.005_959=="Singlet")
VlnPlot(MLY3,features=c("nFeature_RNA", "nCount_RNA", "percent.mt"),ncol=3,group.by="orig.ident")
VlnPlot(MLY3,features="nCount_RNA",ncol=3,group.by="orig.ident",y.max = 25000)
VlnPlot(MLY3,features="percent.ribo",group.by="orig.ident",y.max = 5)
VlnPlot(MLY3,features="percent.mt",ncol=3,group.by="orig.ident",y.max = 10)
VlnPlot(MLY3,features="nFeature_RNA",ncol=3,group.by="orig.ident",y.max = 10000)
MLY3=subset(MLY3,subset=nFeature_RNA>400 & nFeature_RNA<3500 & percent.mt<3 & nCount_RNA<13000)
MLY3@meta.data$group='CTRL'

