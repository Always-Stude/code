library(Seurat)
library(SeuratObject)
library(dplyr)
library(patchwork)
library(sctransform)
library(progress)
library(DoubletFinder)
library(patchwork)

MLY4.data=Read10X("C:\\代码\\数据分析\\MLY4")
MLY4=CreateSeuratObject(counts=MLY4.data,project="MLY4",min.cells=3,min.features=200)
MLY4[["percent.mt"]]=PercentageFeatureSet(MLY4,pattern="^MT-")

MLY4=NormalizeData(MLY4, normalization.method="LogNormalize")
MLY4=FindVariableFeatures(MLY4, selection.method="vst",nfeatures=2000)
all.genes=rownames(MLY4)
MLY4=ScaleData(MLY4, features=all.genes)
MLY4=RunPCA(MLY4)
#Check the elbow shape diagram and heat map
ElbowPlot(MLY4,ndims = 40)
DimHeatmap(MLY4,dims=1:30,cells=500,balanced=TRUE)

MLY4=RunUMAP(MLY4,dims=1:30,verbose=FALSE) 
MLY4=FindNeighbors(MLY4,dims=1:30,verbose=FALSE)
MLY4=FindClusters(MLY4,verbose=FALSE,resolution=0.5)

DimPlot(MLY4,reduction="umap",label=TRUE,repel=TRUE)

#Quality control: First, filter out the double cells
sweep.res.list_keloid=paramSweep(MLY4,PCs=1:30,sct=F)
head(sweep.res.list_keloid)

sweep.stats_keloid=summarizeSweep(sweep.res.list_keloid, GT=FALSE)
bcmvn_keloid=find.pK(sweep.stats_keloid) #可以看到最佳参数的点
#The optimal parameter is: 0.005
mpK=0.005
mpK=as.numeric(as.vector(bcmvn_keloid$pK[which.max(bcmvn_keloid$BCmetric)]))

#Calculate the proportion of two cells
annotations=MLY4@meta.data$seurat_clusters
homotypic.prop=modelHomotypic(annotations)  

#Calculate the proportion of double cells and artificially mix the double cells based on the parameters in modelHomotypic
DoubletRate=0.069
nExp_poi=round(DoubletRate*nrow(MLY4@meta.data))  
nExp_poi.adj=round(nExp_poi*(1-homotypic.prop))

#There are two methods for identifying double cells
MLY4=doubletFinder(MLY4, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi, reuse.pANN=FALSE,sct=F)
MLY4=doubletFinder(MLY4, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi, reuse.pANN="pANN_0.25_0.005_630",sct=F)

MLY4=doubletFinder(MLY4, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi.adj,reuse.pANN=FALSE,sct=F)
MLY4=doubletFinder(MLY4, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi.adj,reuse.pANN="pANN_0.25_0.005_535",sct=F)

#visualization
DimPlot(MLY4,reduction="umap",group.by ="RNA_snn_res.0.5")+DimPlot(MLY4,reduction="umap",group.by ="DF.classifications_0.25_0.005_630",cols=c("black","grey","gold"))
table(MLY4@meta.data$DF.classifications_0.25_0.005_630)#630+8530

DimPlot(MLY4,reduction="umap",group.by ="RNA_snn_res.0.5")+DimPlot(MLY4,reduction="umap",group.by ="DF.classifications_0.25_0.005_535",cols=c("black","grey","gold"))
table(MLY4@meta.data$DF.classifications_0.25_0.005_535)#535+8598

#filtration
MLY4=subset(MLY4,subset=DF.classifications_0.25_0.005_630=="Singlet")
VlnPlot(MLY4,features=c("nFeature_RNA", "nCount_RNA", "percent.mt"),ncol=3,group.by="orig.ident")
VlnPlot(MLY4,features="nCount_RNA",ncol=3,group.by="orig.ident",y.max = 50000)
VlnPlot(MLY4,features="percent.mt",ncol=3,group.by="orig.ident",y.max = 3)
VlnPlot(MLY4,features="nFeature_RNA",ncol=3,group.by="orig.ident",y.max = 10000)
MLY4=subset(MLY4,subset=nFeature_RNA>500 & nFeature_RNA<4500 & percent.mt<1 & nCount_RNA<12000)
MLY4@meta.data$group='STIM'

