library(Seurat)
library(SeuratObject)
library(dplyr)
library(patchwork)
library(sctransform)
library(progress)
library(DoubletFinder)
library(patchwork)

MLY5.data=Read10X("C:\\代码\\数据分析\\MLY5")
MLY5=CreateSeuratObject(counts=MLY5.data,project="MLY5",min.cells=3,min.features=200)
MLY5[["percent.mt"]]=PercentageFeatureSet(MLY5,pattern="^MT-")
#First, simply group them
MLY5=NormalizeData(MLY5, normalization.method="LogNormalize")
MLY5=FindVariableFeatures(MLY5, selection.method="vst",nfeatures=2000)
all.genes=rownames(MLY5)
MLY5=ScaleData(MLY5, features=all.genes)
MLY5=RunPCA(MLY5)
#Check the elbow shape diagram and heat map
ElbowPlot(MLY5,ndims = 40)
DimHeatmap(MLY5,dims=1:30,cells=500,balanced=TRUE)

MLY5=RunUMAP(MLY5,dims=1:30,verbose=FALSE) 
MLY5=FindNeighbors(MLY5,dims=1:30,verbose=FALSE)
MLY5=FindClusters(MLY5,verbose=FALSE,resolution=0.5)

DimPlot(MLY5,reduction="umap",label=TRUE,repel=TRUE)

#Quality control: First, filter out the double cells
sweep.res.list_keloid=paramSweep(MLY5,PCs=1:30,sct=F)
head(sweep.res.list_keloid)

sweep.stats_keloid=summarizeSweep(sweep.res.list_keloid, GT=FALSE)
bcmvn_keloid=find.pK(sweep.stats_keloid) #可以看到最佳参数的点
##所以最佳的参数是：0.005
mpK=0.005
mpK=as.numeric(as.vector(bcmvn_keloid$pK[which.max(bcmvn_keloid$BCmetric)]))

#The optimal parameter is: 0.005
annotations=MLY5@meta.data$seurat_clusters
homotypic.prop=modelHomotypic(annotations)  

#Calculate the proportion of two cells
DoubletRate=0.0425
nExp_poi=round(DoubletRate*nrow(MLY5@meta.data))  
nExp_poi.adj=round(nExp_poi*(1-homotypic.prop))

#There are two methods for identifying double cells
MLY5=doubletFinder(MLY5, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi, reuse.pANN=FALSE,sct=F)
MLY5=doubletFinder(MLY5, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi, reuse.pANN="pANN_0.25_0.005_236",sct=F)

MLY5=doubletFinder(MLY5, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi.adj,reuse.pANN=FALSE,sct=F)
MLY5=doubletFinder(MLY5, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi.adj,reuse.pANN="pANN_0.25_0.005_197",sct=F)

#visualization
DimPlot(MLY5,reduction="umap",group.by ="RNA_snn_res.0.5")+DimPlot(MLY5,reduction="umap",group.by ="DF.classifications_0.25_0.005_236",cols=c("black","grey","gold"))
table(MLY5@meta.data$DF.classifications_0.25_0.005_236)#236+5322

DimPlot(MLY5,reduction="umap",group.by ="RNA_snn_res.0.5")+DimPlot(MLY5,reduction="umap",group.by ="DF.classifications_0.25_0.005_197",cols=c("black","grey","gold"))
table(MLY5@meta.data$DF.classifications_0.25_0.005_197)#197+5361

#filtration
MLY5=subset(MLY5,subset=DF.classifications_0.25_0.005_236=="Singlet")
VlnPlot(MLY5,features=c("nFeature_RNA", "nCount_RNA", "percent.mt"),ncol=3,group.by="orig.ident")
VlnPlot(MLY5,features="percent.mt",ncol=3,group.by="orig.ident",y.max = 1)
VlnPlot(MLY5,features="nCount_RNA",group.by="orig.ident",y.max = 30000)
VlnPlot(MLY5,features="nFeature_RNA",ncol=3,group.by="orig.ident",y.max = 6000)
MLY5=subset(MLY5,subset=nFeature_RNA>1000 & nFeature_RNA<5000 & percent.mt<0.5 & nCount_RNA<20000)
MLY5@meta.data$group='STIM'

