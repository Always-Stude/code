library(Seurat)
library(SeuratObject)
library(dplyr)
library(patchwork)
library(sctransform)
library(progress)
library(DoubletFinder)
library(patchwork)

MLY2.data=Read10X("C:\\Users\\mengxing\\Desktop\\data\\MLY2")
MLY2=CreateSeuratObject(counts=MLY2.data,project="MLY2",min.cells=3,min.features=200)
MLY2[["percent.mt"]]=PercentageFeatureSet(MLY2,pattern="^MT-")
#Calculate ribosome genes
rb.genes=rownames(MLY2)[grep("^RP[SL]",rownames(MLY2))]
percent.ribo=Matrix::colSums(MLY2[rb.genes,])/Matrix::colSums(MLY2)*100
MLY2=AddMetaData(MLY2, percent.ribo, col.name="percent.ribo")



#First, simply group them
MLY2=NormalizeData(MLY2, normalization.method="LogNormalize")
MLY2=FindVariableFeatures(MLY2, selection.method="vst",nfeatures=2000)
all.genes=rownames(MLY2)
MLY2=ScaleData(MLY2, features = all.genes)
MLY2=RunPCA(MLY2)
#Check the elbow shape diagram and heat map
ElbowPlot(MLY2,ndims = 40)
DimHeatmap(MLY2,dims=1:30,cells=500,balanced=TRUE)

MLY2=RunUMAP(MLY2,dims=1:30,verbose=FALSE) 
MLY2=FindNeighbors(MLY2,dims=1:30,verbose=FALSE)
MLY2=FindClusters(MLY2,verbose=FALSE,resolution=0.5)

DimPlot(MLY2,reduction="umap",label=TRUE,repel=TRUE)

#Quality control: First, filter out the double cells
sweep.res.list_keloid=paramSweep(MLY2,PCs=1:30,sct=F)
head(sweep.res.list_keloid)

sweep.stats_keloid=summarizeSweep(sweep.res.list_keloid, GT=FALSE)
bcmvn_keloid=find.pK(sweep.stats_keloid) #可以看到最佳参数的点
#The optimal parameter is: 0.005
mpK=0.005
mpK=as.numeric(as.vector(bcmvn_keloid$pK[which.max(bcmvn_keloid$BCmetric)]))

#Calculate the proportion of two cells
annotations=MLY2@meta.data$seurat_clusters
homotypic.prop=modelHomotypic(annotations)  

#Calculate the proportion of double cells and artificially mix the double cells based on the parameters in modelHomotypic
DoubletRate=0.05
nExp_poi=round(DoubletRate*nrow(MLY2@meta.data))  
nExp_poi.adj=round(nExp_poi*(1-homotypic.prop))

#There are two methods for identifying double cells
MLY2=doubletFinder(MLY2, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi, reuse.pANN=FALSE,sct=F)
MLY2=doubletFinder(MLY2, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi, reuse.pANN="pANN_0.25_0.005_327",sct=F)

MLY2=doubletFinder(MLY2, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi.adj,reuse.pANN=FALSE,sct=F)
MLY2=doubletFinder(MLY2, PCs=1:30, pN=0.25, pK=mpK,nExp=nExp_poi.adj,reuse.pANN="pANN_0.25_0.005_327",sct=F)

#visualization
DimPlot(MLY2,reduction="umap",group.by ="RNA_snn_res.0.5")+DimPlot(MLY2,reduction="umap",group.by ="DF.classifications_0.25_0.005_327",cols=c("black","grey","gold"))
table(MLY2@meta.data$DF.classifications_0.25_0.005_327)#327+6216

DimPlot(MLY2,reduction="umap",group.by ="RNA_snn_res.0.5")+DimPlot(MLY2,reduction="umap",group.by ="DF.classifications_0.25_0.02_287",cols=c("black","grey","gold"))
table(MLY2@meta.data$DF.classifications_0.25_0.02_287)#287+6256

#filtration
MLY2=subset(MLY2,subset=DF.classifications_0.25_0.005_327=="Singlet")
VlnPlot(MLY2,features=c("nFeature_RNA", "nCount_RNA", "percent.mt"),ncol=3,group.by="orig.ident")
VlnPlot(MLY2,features="percent.mt",group.by="orig.ident",y.max = 4)
VlnPlot(MLY2,features="percent.ribo",group.by="orig.ident",y.max = 5)
VlnPlot(MLY2,features="nCount_RNA",group.by="orig.ident",y.max = 30000)
VlnPlot(MLY2,features="nFeature_RNA",group.by="orig.ident",y.max = 10000)
MLY2=subset(MLY2,subset=nFeature_RNA>400 & nFeature_RNA<4000 & percent.mt<2 & nCount_RNA<20000)
MLY2@meta.data$group='CTRL'


