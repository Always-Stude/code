function S = Sfun_PD_NLL(b)
%the negative log-likelihood function of constitutive model

global  pmdata  cellnumber

k=length(pmdata);
for i=1:1:length(pmdata)
    if pmdata(k)>0
        break
    else
        k=length(pmdata)-i;
    end
end
vin=k-1;
N = 3*(vin+1);
NN = min(length(pmdata),N);

pm = poisspdf([0:NN - 1], exp(b(1)));

pm_b = pm;
pm_b(pm_b <= 0) =  1e-10;

% remove NaN and Inf values
logicalIndex = ~isnan(pm_b) & ~isinf(pm_b);
pm_b = pm_b(logicalIndex);

% replace the removed NaN and Inf values so that the distribution sums to 1
pm_b1 = [];
if NN > length(pm_b)
    for i = 1:NN-length(pm_b)
        pm_b1 = [pm_b1 (1 - sum(pm_b))/(NN-length(pm_b))];
    end
end
pm_bb = [pm_b pm_b1];

if min(pm_bb) < 0  ||  max(pm_bb) > 1.0000000001 % remove calculation errors
    S = 1e+30;
else
    if sum(pm_bb) < 0.99 || sum(pm_bb) > 1.01 %ensure the sum of the simulated distribution is close to 1
        S = 1e+30;
    else
        %the negative log-likelihood function
        S = 0;
        for i = 1:NN
            S = S - cellnumber(i).*log(pm_bb(i));
        end
    end
end


end
