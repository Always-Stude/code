function parfit_twostate
clc
close all
clear all

str={'name','telegraph model','kon (bf)', ' koff', 'kb','kb/koff (bs1)', 'AICc_telegraph model','constitutive model', 'mean', 'AICc_constitutive model', 'bursty model', 'bf', 'bs', 'AICc_bursty model', ...
    'model selection','model'};

filename='result.xlsx';
[data,~,all_]=xlsread('example_human_Health_cardiomyocytes_gene.xlsx');       %%Import data
xlswrite(filename,str,1,'A1')

for zushu=1:1:length(data(:,1))
    
    clearvars -except zushu data filename all_
    
    global  pmdata cellnumber
    
    N = 774;   % cell numbers

    pmdata = data(zushu,:);
    pmdata = pmdata(~isnan(pmdata)); %remove NaN values
    pmdata = transpose(pmdata);
    
    S = length(pmdata);
    for i=1:1:S
        cellnumber(i)=N.*pmdata(i);
    end
    for i = 1:1:S
        cellnumber(i) = N.*pmdata(i);
    end
    
    kon_e = []; koff_e = []; kb_e = [];Smin_TM = [];
    mean_e = []; Smin_PD = [];
    bf_e = []; bs_e = [];  Smin_NBD = [];
    for i = 1:20
        
        if pmdata(1) <0.95
            
            % fit to telegraph model
            konini = 0.1 + 9.9*rand;
            kofini = 0.1 + 9.9*rand;
            kbini = 5 + 49*rand;
            
            ini = [log(konini)  log(kofini)  log(kbini)];
            [bminTM, SminTM] = fminsearch(@Sfun_TM_NLL,ini);  %call the negative log-likelihood function of telegraph model
            kon_e = [kon_e exp(bminTM(1))];
            koff_e = [koff_e exp(bminTM(2))];
            kb_e = [kb_e exp(bminTM(3))+1];
            Smin_TM = [Smin_TM SminTM];
            
            % fit to constitutive model
            meanin = 1 + 99*rand;
            ini = [log(meanin)];
            [bminPD1, SminPD1] = fminsearch(@Sfun_PD_NLL,ini); %call the negative log-likelihood function of constitutive model
            mean_e = [mean_e exp(bminPD1(1))];
            Smin_PD = [Smin_PD SminPD1];
            
            %  fit to bursty model
            bfin = 0.1 + 9.9*rand;
            bsin = 0.1 + 49.9*rand;
            ini = [log(bfin) log(bsin)];
            [bminNBD1, SminNBD1] = fminsearch(@Sfun_NBD_NLL,ini); %call the negative log-likelihood function of bursty model
            bf_e = [bf_e exp(bminNBD1(1))];
            bs_e = [bs_e exp(bminNBD1(2))];
            Smin_NBD = [Smin_NBD SminNBD1];
            
        else   % genes with almost no expression
            kon_e = [kon_e 0];
            koff_e = [koff_e 1e+40];
            kb_e = [kb_e 0];
            Smin_TM = [Smin_TM 1e+40];
            mean_e = [mean_e 0];
            Smin_PD = [Smin_PD 1e+40];
            bf_e = [bf_e 0];
            bs_e = [bs_e 0];
            Smin_NBD = [Smin_NBD 1e+40];
        end
        
    end
    
    zushu
    
    % select the estimation result with the minimum negative log-likelihood from 20 likelihood estimations as our final result
    Smin_minTM = min(Smin_TM);
    Smin_minTM_loction = find(Smin_TM==Smin_minTM);
    kon = kon_e(Smin_minTM_loction(1));
    koff = koff_e(Smin_minTM_loction(1));
    kb = kb_e(Smin_minTM_loction(1));
    k = 3;
    AICc_TM = 2*Smin_minTM + 2*k + k*(k+1)/(N-k-1);
    xlswrite(filename,[all_(zushu+1,1)],1,['A',num2str(zushu+1)])
    xlswrite(filename,[kon  koff  kb kb/koff AICc_TM],1,['C',num2str(zushu+1)])
    
    Smin_minPD = min(Smin_PD);
    Smin_minPD_loction = find(Smin_PD==Smin_minPD);
    mean = mean_e(Smin_minPD_loction(1));
    k = 1;
    AICc_PD = 2*Smin_minPD + 2*k + k*(k+1)/(N-k-1);
    xlswrite(filename,[mean AICc_PD],1,['I',num2str(zushu+1)])
    
    Smin_minNBD = min(Smin_NBD);
    Smin_minNBD_loction = find(Smin_NBD==Smin_minNBD);
    bf = bf_e(Smin_minNBD_loction(1));
    bs = bs_e(Smin_minNBD_loction(1));
    k = 2;
    AICc_NBD = 2*Smin_minNBD + 2*k + k*(k+1)/(N-k-1);
    xlswrite(filename,[bf bs AICc_NBD],1,['L',num2str(zushu+1)])
    
    % model selection:
    if AICc_TM == min([AICc_TM AICc_PD AICc_NBD])  
        xlswrite(filename,[1],1,['P',num2str(zushu+1)]) % 1: telegraph model
    end
    if AICc_PD == min([AICc_TM AICc_PD AICc_NBD])
        xlswrite(filename,[2],1,['P',num2str(zushu+1)]) % 2: constitutive model
    end
    if AICc_NBD == min([AICc_TM AICc_PD AICc_NBD])
        xlswrite(filename,[3],1,['P',num2str(zushu+1)]) % 3: bursty model
    end
    if pmdata(1) >= 0.95
        xlswrite(filename,[4],1,['P',num2str(zushu+1)]) % 4: genes with almost no expression.Do not select the model
    end
     
end

end

