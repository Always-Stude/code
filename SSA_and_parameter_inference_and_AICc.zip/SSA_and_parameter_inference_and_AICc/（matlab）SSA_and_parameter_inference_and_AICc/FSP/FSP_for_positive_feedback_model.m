function FSP_for_positive_feedback_model
clc
clear all

    kon = 0.1 + 2.9*rand;  koff = 0.1 + 4.9*rand; kb = 5 + 45*rand; mu = 0.05 + 1.95*rand; 
    kd = 1;
    
    TT=200;
    M=ceil(3*kb+1);
    dt=0.001;   S=TT/dt+1;   
    p1=zeros(S,M+1); p2=zeros(S,M+1);
    p1(1,1)=1; p2(1,1)=0;
    for j=2:1:M+1
        p2(1,j)=0;
        p1(1,j)=0;
    end
    for ta=2:S 
        p1(ta,1)=p1(ta-1,1)+dt*(kd*p1(ta-1,2)+koff*p2(ta-1,1)-kon*p1(ta-1,1));
        p2(ta,1)=p2(ta-1,1)+dt*(kd*p2(ta-1,2)+kon*p1(ta-1,1)-(kb+koff)*p2(ta-1,1));
        for i=2:M  
            p1(ta,i)=p1(ta-1,i)+dt*(koff*p2(ta-1,i)-((i-1)*(kd+mu)+kon)*p1(ta-1,i)+i*kd*p1(ta-1,i+1));
            p2(ta,i)=p2(ta-1,i)+dt*((kon+(i-1)*mu)*p1(ta-1,i)-(kb+(i-1)*kd+koff)*p2(ta-1,i)+i*kd*p2(ta-1,i+1)+kb*p2(ta-1,i-1));
        end
    end
    pM=p1+p2; 
    pM(end,:); % steady-state probability distribution
    
    filename='FSP_for_positive_feedback_steady_state_distribution.xlsx'
    xlswrite(filename,pM(end,:)',1,['A','1'])
end


