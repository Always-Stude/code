function SSA_for_telegraph_model
clc
clear all

for zushu=1:1:500
    clearvars -except zushu
    tic
    % Configure the parameter random sampling range
    kon = 0.1+4.9*rand; koff = 0.1+4.9*rand; kb = 5+45*rand;
    kd = 1;
    
    str1 = {num2str(kon),num2str(koff),num2str(kb)}';
    
    TT = 200;  H = 200;  eps = 0.01;
    TP(1) = TT/H;
    for i = 2:1:H
        TP(i) = TT/H+TP(i-1) ;
    end
    
    % Determining steady-state time from the mean and second-order moment
    odefun = @(t,y)[
        koff*y(2) - kon*y(1);
        kon*y(1) - koff*y(2);
        kb*y(2) - kd*y(3);
        -(koff+kd)*y(4) + kon*y(5) + kb*y(2);
        koff*y(4) - (kon+kd)*y(5);
        -2*kd*y(6) + kd*y(3) + kb*y(2) + 2*kb*y(4);
        ];
    
    y00 = [1,0,0,0,0,0];
    options = odeset('reltol',1e-8,'abstol',1e-8);
    [t,y] = ode45(odefun,[0,TT],y00,options);
    
    for j = 1:1:H
        for i = 1:1:length(t)
            if t(i) >= TP(j)
                break
            end
            k(j) = i+1;
        end
    end
    
    for j = 1:1:H
        meandata(j) = y(k(j),3);
        seconddata(j) = y(k(j),6);
    end
    
    kk = H;
    for j=1:1:H-1
        if  abs(meandata(H)-meandata(H-j))/meandata(H) <= eps
            kk = kk-1;
        else
            break
        end
    end
    meantime = kk*(TT/H);
    
    kk1 = H;
    for j = 1:1:H-1
        if  abs(seconddata(H)-seconddata(H-j))/seconddata(H) < eps
            kk1 = kk1-1;
        else
            break
        end
    end
    secondtime = kk1*(TT/H);
    
    tend = max(meantime,secondtime);  % Steady-state time
    
    if zushu <= 26
        location = char(65+mod(zushu-1,1000));
    end
    for i = 1:26
        if zushu <= 26*(i+1) && zushu >= 26*i+1
            location = char([65+mod((i-1),1000), 65+mod(zushu-(26*i+1),1000)]);
        end
    end
    for i = 1:26
        if zushu <= 26*(26+i+1) && zushu >= 26*(26+i)+1
            location = char([65+mod(0,1000), 65+mod(i-1,1000),65+mod(zushu-(26*(i+26)+1),1000)]);
        end
    end
    
    
    filename = 'N100_telegraph model.xlsx'
    range1 = [location,'1:',location,'3'];
    xlswrite(filename,str1,1,range1)  % Save the sampled random parameter values to a list
    
    N = 100;  % Sample size
    T = tend;    %  Steady-state time
    M = 3*ceil(kb)+1;
    X(1) = 0; t(1) = 0;  % Initialize: molecules = 0, time = 0
    Send = [];
    for i = 1:N
        s(1)=1;
        n = 1;
        Xall = [X(1)]; Sall = [s(1)]; tall = [t(1)];
        while t(n) <= T
            h1 = 1; c1 = kb; a1 = h1*c1;   % generate
            h2 = 1; c2 = koff; a2 = h2*c2; % ON --> OFF
            h3 = 1; c3 = kon; a3 = h3*c3;  % OFF --> ON
            h4 = X(n); c4 = kd; a4 = h4*c4;  % decay
            n = n+1;
            
            if s(n-1) == 0 % ON state
                a0 = a1+a2+a4;
                r1 = rand; r2=rand;
                tau = -log(r1)/a0;  % time interval in which nothing occurs
                if a0*r2 <= a1 % generate occurs
                    X(n) = X(n-1)+1;  s(n) = 0;
                elseif a0*r2 <= a1+a2  % transition occurs
                    X(n) = X(n-1);  s(n) = 1;
                else % decay
                    X(n) = X(n-1)-1; s(n) = 0;
                end
                t(n) = t(n-1) + tau;
            else    % OFF state
                a0 = a3+a4;
                r1 = rand;  r2 = rand;
                tau = -log(r1)/a0;
                if a0*r2 <= a3 % transition occurs
                    X(n) = X(n-1); s(n) = 0;
                else % decy occurs
                    X(n) = X(n-1)-1; s(n) = 1;
                end
                t(n) = t(n-1) + tau;
            end
            tall = [tall t(n)]; Xall = [Xall X(n)]; Sall = [Sall s(n)];  % The random jump times, and the trajectories of both the molecule count and the system state over time
        end
        for j=2:n
            if t(j-1) <= tend && t(j) > tend
                Send = [Send X(j-1)];
            end
        end
    end
    
    for i = 1:M
        pmdata(i) = sum(Send==(i-1))/N;
    end
    
    
    range3 = [location,'4'];
    xlswrite(filename,pmdata',1,range3)  % Save the simulated distribution data to a list
    
    zushu
    toc
    
end

