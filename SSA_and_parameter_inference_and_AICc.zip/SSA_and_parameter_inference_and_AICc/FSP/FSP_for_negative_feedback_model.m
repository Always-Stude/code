function FSP_for_negative_feedback_model

    kon = 0.1 + 4.9*rand;   koff = 0.1 + 2.9*rand;  kb = 5 + 45*rand;  nu = 0.05 + 0.95*rand; 
    kd = 1;
    
    TT = 200;
    M = ceil(3*kb+1);
    dt = 0.001;   S = TT/dt + 1;  
    p1 = zeros(S,M+1); p2 = zeros(S,M+1);
    p1(1,1) = 1; p2(1,1) = 0;
    for j = 2:1:M+1
        p2(1,j) = 0;
        p1(1,j) = 0;
    end
    for ta = 2:S 
        p1(ta,1) = p1(ta-1,1) + dt*(kd*p1(ta-1,2) + koff*p2(ta-1,1)-kon*p1(ta-1,1));
        p2(ta,1) = p2(ta-1,1) + dt*(kd*p2(ta-1,2) + kon*p1(ta-1,1)-(kb+koff)*p2(ta-1,1));
        for i = 2:M  
            p1(ta,i) = p1(ta-1,i) + dt*((koff + (i-1)*nu) * p2(ta-1,i) - ((i-1)*kd + kon) * p1(ta-1,i) + i*kd*p1(ta-1,i+1));
            p2(ta,i) = p2(ta-1,i) + dt*(kon*p1(ta-1,i) - (kb+(i-1)*(kd+nu) + koff)*p2(ta-1,i) + i*kd*p2(ta-1,i+1) + kb*p2(ta-1,i-1));
        end
    end
    pM = p1 + p2;
    pM(end,:) % steady-state probably
end

    
